package com.sarftec.lifelessons.application.enums

enum class Destination {
    LOAD, SPLASH, MAIN, LIST, FAVORITE, QUOTE
}