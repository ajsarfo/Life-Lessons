package com.sarftec.lifelessons.data.database

const val QUOTE_TABLE = "quote_table"
const val CATEGORY_TABLE = "category_table"