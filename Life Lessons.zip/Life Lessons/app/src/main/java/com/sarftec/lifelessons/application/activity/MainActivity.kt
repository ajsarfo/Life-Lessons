package com.sarftec.lifelessons.application.activity

import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.appodeal.ads.Appodeal
import com.sarftec.lifelessons.R
import com.sarftec.lifelessons.application.adapter.MainItemAdapter
import com.sarftec.lifelessons.application.binding.AboutDialogBinding
import com.sarftec.lifelessons.application.binding.MainToolbarBinding
import com.sarftec.lifelessons.application.dialog.AboutDialog
import com.sarftec.lifelessons.application.dialog.LoadingDialog
import com.sarftec.lifelessons.application.file.vibrate
import com.sarftec.lifelessons.application.manager.AppReviewManager
import com.sarftec.lifelessons.application.manager.InterstitialManager
import com.sarftec.lifelessons.application.viewmodel.MainViewModel
import com.sarftec.lifelessons.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : BaseActivity() {

    private val binding by lazy {
        ActivityMainBinding.inflate(
            LayoutInflater.from(this)
        )
    }

    private val interstitialManager by lazy {
        InterstitialManager(
            this,
            networkManager,
            listOf(1, 3, 4, 3)
        )
    }

    private val aboutDialog by lazy {
        AboutDialog(
            AboutDialogBinding(dependency).also {
                it.init()
            },
            binding.root
        )
    }

    private val loadingDialog by lazy {
        LoadingDialog(this)
    }

    private val mainItemAdapter by lazy {
        MainItemAdapter(dependency, viewModel) { item ->
            interstitialManager.showAd {
                navigateTo(
                    ListActivity::class.java,
                    bundle = Bundle().apply {
                        putString(CATEGORY_SELECTED_NAME, item.category)
                    }
                )
            }
        }
    }

    private val viewModel by viewModels<MainViewModel>()

    fun configureToolbarLayout() {
        with(binding.toolbarLayout) {
            binding = MainToolbarBinding(
                dependency,
                {
                    vibrate()
                    navigateTo(FavoriteActivity::class.java)
                },
                {
                    vibrate()
                    aboutDialog.show()
                }
            ).also {
                it.init()
            }
            executePendingBindings()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        statusColor(ContextCompat.getColor(this, R.color.main_status))
        setStatusBarBackgroundLight()
        /*************** Appodeal Configuration ********************/
        Appodeal.setTesting(true)
        Appodeal.setBannerViewId(R.id.main_banner)
        Appodeal.initialize(
            this,
            getString(R.string.appodeal_id),
            Appodeal.BANNER_VIEW or Appodeal.INTERSTITIAL
        )
        /**********************************************************/
        loadingDialog.show()
        configureToolbarLayout()
        with(binding.recyclerView) {
            layoutManager = LinearLayoutManager(this@MainActivity)
            setHasFixedSize(true)
            adapter = mainItemAdapter
        }
        viewModel.quotes.observe(this) {
            mainItemAdapter.submitData(it)
            loadingDialog.dismiss()
        }
        with(AppReviewManager(this)) {
            init()
            lifecycleScope.launchWhenCreated {
                triggerReview()
            }
        }
    }

    override fun onBackPressed() {
        finish()
    }

    override fun onResume() {
        super.onResume()
        Appodeal.show(this, Appodeal.BANNER_VIEW)
    }

    override fun onPause() {
        super.onPause()
        Appodeal.hide(this, Appodeal.BANNER_VIEW)
    }
}