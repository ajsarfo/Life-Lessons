package com.sarftec.lifelessons.data

const val CATEGORY_QUOTES_FILE = "quotes/category_quotes.json"