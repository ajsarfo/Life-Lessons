package com.sarftec.lifelessons.application.model

data class MainItem(
    val category: String,
    val randomQuote: String,
    val size: Int
)